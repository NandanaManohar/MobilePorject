Simple Memory Game made in android studio.
For download click on the green code button and download the zip.
